from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from orchestrator import Orchestrator
import os

app = FastAPI(title="ADK Multi-Agent Capstone (LLM-enabled)")
orchestrator = Orchestrator()

class OrchestrateRequest(BaseModel):
    session_id: str
    goal: str

@app.post('/orchestrate')
async def orchestrate(req: OrchestrateRequest):
    try:
        result = await orchestrator.handle_goal(req.session_id, req.goal)
        return {"status":"ok","result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get('/health')
async def health():
    return {"status":"healthy"}
