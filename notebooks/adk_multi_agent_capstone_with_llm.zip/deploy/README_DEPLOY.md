Deployment and production guidance

- Use Secret Manager to store GEMINI_API_KEY and other secrets.
- Use Workload Identity for Cloud Run to avoid embedding GCP JSON keys.
- Consider switching MemoryStore to a managed DB or vector DB for multi-instance persistence.
- Add authentication (IAP or Cloud Run IAM) to protect the /orchestrate endpoint.
