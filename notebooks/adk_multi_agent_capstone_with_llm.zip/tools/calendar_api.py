class CalendarTool:
    def create_tentative_event(self, session_id, title, date):
        # placeholder implementation. For production, integrate with Google Calendar API (OAuth2).
        print(f"[CalendarTool] Created tentative event for {session_id}: {title} on {date}")
        return {"status":"ok","title":title,"date":date}
