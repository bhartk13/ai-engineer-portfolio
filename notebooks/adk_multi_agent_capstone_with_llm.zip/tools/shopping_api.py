class ShoppingTool:
    """Mock shopping tool. Replace with real API integration (e.g., retailer APIs)."""
    def get_optimized_list(self, items):
        flat=[]
        for k,v in items.items():
            flat += v
        optimized = list(dict.fromkeys(flat))
        priced = [{"item":i, "qty":1, "price": round(len(i)*0.5+1.5,2)} for i in optimized]
        total = sum(p['price'] for p in priced)
        return {"items": priced, "total": round(total,2)}
