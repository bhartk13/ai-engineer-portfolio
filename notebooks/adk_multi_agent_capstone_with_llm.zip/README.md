# ADK Multi-Agent Capstone (LLM-enabled)

This project is an updated capstone starter that includes **plug-and-play LLM calls** (Google Gemini via `google-genai` SDK) inside agent implementations, with safe fallbacks to mock logic if the `GEMINI_API_KEY` is not provided or `genai` is not installed.

## Features
- FastAPI backend with orchestrator (`POST /orchestrate`)
- Three agents: MealPlanner, ShoppingAgent, TravelPlanner — each uses an LLM call if available
- Memory store (SQLite) for sessions
- Tool integration points (Calendar, Shopping) — mocked but easy to replace
- Dockerfile and Cloud Build config for Cloud Run deployment
- `.env.example` with required environment variables
- Safety: Agents auto-fallback to deterministic mock responses when LLM not available

## Quick start (local)
1. Create venv and install requirements:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```
2. Create `.env` from `.env.example` and set `GEMINI_API_KEY` if you want real LLM calls.
3. Run the server:
```bash
uvicorn main:app --reload --port 8080
```
4. Test:
```bash
curl -X POST "http://localhost:8080/orchestrate" -H "Content-Type: application/json"   -d '{"session_id":"user123","goal":"Plan dinners for next 3 days and a shopping list"}'
```

## Environment / Secrets you'll need
- `GEMINI_API_KEY` — API key for Google Gemini (GenAI SDK). If absent, agents use mocks.
- `GOOGLE_APPLICATION_CREDENTIALS` — only required if you use GCP SDKs (Firestore, Calendar with service account).
- `PROJECT_ID` — GCP project id for deployment.

## Notes
- The included code is ready to be extended into ADK agent classes or Vertex Agent Engine usage.
- Never store secrets directly in code; use Secret Manager for production deployments.
