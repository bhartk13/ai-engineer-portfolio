import asyncio, json
from memory.store import MemoryStore
from agents.meal_planner import MealPlannerAgent
from agents.shopping import ShoppingAgent
from agents.travel_planner import TravelPlannerAgent
from typing import Dict

class Orchestrator:
    def __init__(self):
        self.memory = MemoryStore('memory.db')
        self.meal_agent = MealPlannerAgent(self.memory)
        self.shop_agent = ShoppingAgent(self.memory)
        self.travel_agent = TravelPlannerAgent(self.memory)

    async def handle_goal(self, session_id: str, goal: str) -> Dict:
        # create or update session
        self.memory.create_session(session_id, {"goal": goal})

        # Ask orchestrator LLM (if available) to plan which agents to call. For now, simple heuristic:
        agents_to_call = ["meal","shopping"]
        if 'travel' in goal.lower() or 'trip' in goal.lower():
            agents_to_call.append("travel")

        results = {}
        # Call agents concurrently where helpful (meal -> shopping depends on meal output)
        # 1) Run meal planner
        meal = await self.meal_agent.plan_meals(session_id, goal)
        results['meal'] = meal

        # 2) Run shopping agent using meal shopping_list
        shopping = await self.shop_agent.optimize_shopping(session_id, meal)
        results['shopping'] = shopping

        # 3) Optional travel
        travel = None
        if "travel" in agents_to_call:
            travel = await self.travel_agent.plan_trip(session_id, goal)
            results['travel'] = travel

        combined = {"meal_plan": meal, "shopping": shopping, "travel": travel}
        self.memory.append_session(session_id, {"combined_plan": combined})
        return combined
