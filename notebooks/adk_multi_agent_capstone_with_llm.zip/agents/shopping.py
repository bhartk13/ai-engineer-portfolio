import os, time, json
from typing import Dict
from tools.shopping_api import ShoppingTool

# LLM wrapper
try:
    from google import genai
    GENAI_AVAILABLE = True
    client = genai.Client(api_key=os.getenv('GEMINI_API_KEY'))
except Exception:
    GENAI_AVAILABLE = False
    client = None

class ShoppingAgent:
    def __init__(self, memory):
        self.memory = memory
        self.tool = ShoppingTool()

    async def optimize_shopping(self, session_id: str, meal_plan: Dict) -> Dict:
        shopping = meal_plan.get('shopping_list', {}) if meal_plan else {}
        prompt = f"""You are a shopping optimization assistant.
Given shopping categories and items: {shopping}
Return a JSON object with keys: items (list of {{item, qty}}) and total_estimate (number).
"""
        if GENAI_AVAILABLE and os.getenv('GEMINI_API_KEY'):
            try:
                resp = client.models.generate_content(model='gemini-1.5-flash', contents=prompt)
                text = resp.text if hasattr(resp, 'text') else str(resp)
                try:
                    parsed = json.loads(text)
                    optimized = parsed
                except Exception:
                    optimized = None
            except Exception:
                optimized = None
        else:
            optimized = None

        if not optimized:
            optimized = self.tool.get_optimized_list(shopping)

        self.memory.append_session(session_id, {"optimized_shopping": optimized})
        time.sleep(0.03)
        return optimized
