import os, time, json
from typing import Dict

# LLM wrapper: attempt to import google-genai, otherwise fallback to mock
try:
    from google import genai
    GENAI_AVAILABLE = True
    client = genai.Client(api_key=os.getenv('GEMINI_API_KEY'))
except Exception:
    GENAI_AVAILABLE = False
    client = None

class MealPlannerAgent:
    def __init__(self, memory):
        self.memory = memory

    async def plan_meals(self, session_id: str, goal: str) -> Dict:
        # read preferences (if any)
        prefs = self.memory.get_session(session_id).get('preferences', {})

        prompt = f"""You are a helpful meal planning assistant.
User goal: {goal}
User preferences: {prefs}

Output JSON with keys: meals (list of day->meals) and shopping_list (category->items).
"""
        # If LLM is available and API key set, call it. Otherwise return deterministic mock.
        if GENAI_AVAILABLE and os.getenv('GEMINI_API_KEY'):
            try:
                resp = client.models.generate_content(model='gemini-1.5-pro', contents=prompt)
                text = resp.text if hasattr(resp, 'text') else str(resp)
                # try to parse JSON out of model output
                try:
                    parsed = json.loads(text)
                    meals = parsed.get('meals')
                    shopping_list = parsed.get('shopping_list')
                except Exception:
                    # best-effort extraction if model returned natural text; fall back to mock
                    meals = None
                    shopping_list = None
            except Exception:
                meals = None
                shopping_list = None
        else:
            meals = None
            shopping_list = None

        # If LLM didn't produce structured result, use mock deterministic plan
        if not meals or not shopping_list:
            meals = [
                {"day":"Day 1", "breakfast":"Oatmeal with fruits", "lunch":"Chickpea salad", "dinner":"Vegetable curry with rice"},
                {"day":"Day 2", "breakfast":"Eggs and toast", "lunch":"Paneer wrap", "dinner":"Pasta with tomato sauce"},
                {"day":"Day 3", "breakfast":"Smoothie bowl", "lunch":"Lentil soup", "dinner":"Stir-fried vegetables with noodles"},
            ]
            shopping_list = {
                "fruits":["banana","apple"],
                "vegetables":["spinach","tomato","onion","garlic"],
                "protein":["chickpeas","paneer","eggs"]
            }

        # save to memory
        self.memory.append_session(session_id, {"meals": meals, "shopping_list": shopping_list})
        # simulate small delay
        time.sleep(0.05)
        return {"meals": meals, "shopping_list": shopping_list}
