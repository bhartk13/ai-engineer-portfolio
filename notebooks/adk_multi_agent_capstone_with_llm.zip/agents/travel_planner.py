import os, time, json
from typing import Dict
from tools.calendar_api import CalendarTool

# LLM wrapper
try:
    from google import genai
    GENAI_AVAILABLE = True
    client = genai.Client(api_key=os.getenv('GEMINI_API_KEY'))
except Exception:
    GENAI_AVAILABLE = False
    client = None

class TravelPlannerAgent:
    def __init__(self, memory):
        self.memory = memory
        self.cal = CalendarTool()

    async def plan_trip(self, session_id: str, goal: str) -> Dict:
        prompt = f"""You are a travel planning assistant.
User goal: {goal}
Return JSON: itinerary (list of day->activities), flights (list), hotels (list), budget_estimate.
"""
        if GENAI_AVAILABLE and os.getenv('GEMINI_API_KEY'):
            try:
                resp = client.models.generate_content(model='gemini-1.5-flash', contents=prompt)
                text = resp.text if hasattr(resp, 'text') else str(resp)
                try:
                    parsed = json.loads(text)
                    itinerary = parsed.get('itinerary')
                    flights = parsed.get('flights')
                    hotels = parsed.get('hotels')
                    budget = parsed.get('budget_estimate')
                except Exception:
                    itinerary = flights = hotels = budget = None
            except Exception:
                itinerary = flights = hotels = budget = None
        else:
            itinerary = None
            flights = None
            hotels = None
            budget = None

        if not itinerary:
            itinerary = [{"day":"Day 1","plan":"Arrive, local sightseeing"},{"day":"Day 2","plan":"Sightseeing"}]
            flights = [{"from":"SEA","to":"VAN","date":"2025-12-01"}]
            hotels = ["Sample Hotel A"] 
            budget = {"currency":"USD","estimate":450}

        # create tentative calendar event
        self.cal.create_tentative_event(session_id, "Trip planning", "2025-12-01")
        self.memory.append_session(session_id, {"itinerary": itinerary, "flights": flights, "hotels": hotels, "budget": budget})
        time.sleep(0.02)
        return {"itinerary": itinerary, "flights": flights, "hotels": hotels, "budget": budget}
